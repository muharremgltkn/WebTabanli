<?php 


echo '


<!-- Footer -->
<footer class="py-3 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Tüm Hakları Maarremde Saklıdır</p>
    </div>
</footer>

';


?>