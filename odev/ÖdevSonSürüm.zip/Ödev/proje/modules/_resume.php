<?php 


echo '

<!-- Resume Section -->
<section id="resume" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <h1>Hakkımda</h1>
                <ul>
                    <li>
                        <h2>Eğitim</h2>
                        <p>İlkokul ve Ortaokul Eğitimi: <a href="https://gurunataturkortaokulu.meb.k12.tr">Sivas Gürün Atatürk Ortaokulu</a></p>
                        <p>Lise Eğitimi: <a href="https://sehitlerfenlisesi.meb.k12.tr/">Yatılı Yozgat Şehitler Fen Lisesi</a></p>
                        <p>Lisans Eğitimi: <a href="https://www.sakarya.edu.tr/">Sakarya Üniversitesi Bilgisayar Mühendisliği Bölümü</a>(Devam Ediyor)</p>

                    </li>
                    <li>
                        <h2>Deneyimlerim</h2>
                        <p>Deneyimlerim arasında en değerli gördüklerim hiç şüphesiz python ile yazdığım otomasyon sistemleridir. Bu sistemler gerek adb gerek selenium ile yazılmış çeşitli otomasyonları içeriyor.</p>
                    </li>
                    <li>
                        <h2>Yeteneklerim</h2>
                        <p>Python, C#, HTML, CSS, C++, JavaScript</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

';


?>